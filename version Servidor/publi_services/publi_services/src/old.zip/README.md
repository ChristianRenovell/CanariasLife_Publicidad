# CRUD Nodejs and Mysql
this is a basic application crud that uses nodejs in the backend, mysql as database.

# Usefull Commands
- to init mysql: `mysql -u root -p`

# links
- [bootstrap 4 theme](https://bootswatch.com/4/lux/bootstrap.min.css)
